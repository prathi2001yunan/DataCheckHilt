package tech.crypton.daggerhilt.data

data class Session(val userEmail: String = "", val userPassword: String = "")
