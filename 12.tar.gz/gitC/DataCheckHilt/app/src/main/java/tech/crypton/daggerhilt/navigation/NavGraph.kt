package tech.crypton.daggerhilt.navigation

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import tech.crypton.daggerhilt.screens.DashBoardScreen
import tech.crypton.daggerhilt.screens.LoginScreen
import tech.crypton.daggerhilt.screens.ProfileScreen
import tech.crypton.daggerhilt.viewmodel.LoginViewModel

@Composable
fun NavGraph(
    navController: NavHostController = rememberNavController(),
    context: Context,
    viewModel: LoginViewModel
) {
    NavHost(
        navController = navController ,
        startDestination = if (! viewModel.isAuthenticated.value) Screens.LoginScreen.route else Screens.DashBoardScreen.route ,
    ) {
        composable(route = Screens.LoginScreen.route) {
            LoginScreen({ _email: String , _password: String ->
                viewModel.afterLogin(
                    _email ,
                    _password
                )
            } , viewModel.email , viewModel.password , viewModel.visible , context) {
                navController.navigate(Screens.DashBoardScreen.route) {
                    navController.popBackStack(Screens.LoginScreen.route , true)
                }
            }
        }
        composable(route = Screens.DashBoardScreen.route) {
            DashBoardScreen(viewModel.dataStoreState.value.userEmail) {
                navController.navigate(
                    Screens.ProfileScreen.route
                )
                
            }
        }
        composable(route = Screens.ProfileScreen.route) {
            ProfileScreen(viewModel.dataStoreState.value.userEmail) {
                navController.navigate(Screens.LoginScreen.route) {
                    navController.popBackStack(Screens.DashBoardScreen.route , true)
                }
            }
        }
    }
}



