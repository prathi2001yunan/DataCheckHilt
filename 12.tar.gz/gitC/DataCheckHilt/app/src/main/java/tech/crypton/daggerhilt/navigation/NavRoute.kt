package tech.crypton.daggerhilt.navigation

sealed class Screens(val route: String) {
    object LoginScreen : Screens("login_screen")

    object DashBoardScreen : Screens("dashboard_screen")

    object ProfileScreen : Screens("profile_screen")
}
