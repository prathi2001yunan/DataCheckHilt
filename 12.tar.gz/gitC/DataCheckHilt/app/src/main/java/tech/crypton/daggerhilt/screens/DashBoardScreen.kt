package tech.crypton.daggerhilt.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import tech.crypton.daggerhilt.R


@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashBoardScreen(userName: String ,onNavigate: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "DashBoard Page -$userName ", color = Color.White, fontWeight = FontWeight.ExtraBold) },
                colors =
                    TopAppBarDefaults.largeTopAppBarColors(
                        Color(0xFF866AD3),
                    ),
                actions = {
                    Row(
                        modifier =
                            Modifier.clickable { onNavigate() }.background(
                                Color(0x59C0C0C2),
                                RoundedCornerShape(5.dp),
                            ).width(100.dp).height(40.dp).clip(
                                RoundedCornerShape(5.dp),
                            ),
                        Arrangement.Center,
                        Alignment.CenterVertically,
                    ) {
                        Icon(
                            modifier = Modifier.size(30.dp),
                            painter = painterResource(id = R.drawable.baseline_miscellaneous_services_24),
                            contentDescription = "",
                            tint = Color.White,
                        )
                        Text(
                            text = "Profile",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White,
                        )
                    }
                },
            )
        },
        content = {
        },
    )
}
