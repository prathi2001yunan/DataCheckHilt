
package tech.crypton.daggerhilt.screens

import android.annotation.SuppressLint
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import tech.crypton.daggerhilt.R


@SuppressLint("UnrememberedMutableState")
@Composable
fun LoginScreen(
    afterLogin: (String , String) -> Unit ,
    email: MutableState<String> ,
    password: MutableState<String> ,
    visible: MutableState<Boolean> ,
    context: Context ,
    onNavigate: () -> Unit ,
) {
    val height = LocalConfiguration.current.screenHeightDp.dp
    Column(
        modifier = Modifier.fillMaxSize().background(if (isSystemInDarkTheme()) Color.Black else Color.White),
        Arrangement.Center,
        Alignment.CenterHorizontally,
    ) {
        Text(text = "LogIn Page", fontWeight = FontWeight.W800, fontSize = 30.sp)
        Spacer(modifier = Modifier.fillMaxHeight(0.1f))
        Card(
            modifier =
                Modifier
                    .fillMaxHeight(if (height > 700.dp) 0.55f else 0.75f)
                    .fillMaxWidth()
                    .padding(horizontal = 50.dp),
            colors =
                CardDefaults.cardColors(
                    if (isSystemInDarkTheme()) {
                        Color(
                            0xFF2F2E30,
                        )
                    } else {
                        Color(0xA9FFFEFE)
                    },
                ),
            shape = RoundedCornerShape(20.dp),
        ) {
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(20.dp),
            ) {
                LoginEmailInput(email)
                Spacer(modifier = Modifier.fillMaxHeight(0.05F))
                LoginPasswordInput(password = password, visible = visible)
                Spacer(modifier = Modifier.fillMaxHeight(0.2F))
                LoginButton(afterLogin,email = email, password = password, onNavigate = onNavigate, context = context)
            }
        }
    }
}

@Composable
private fun LoginButton(
    afterLogin: (String , String) -> Unit ,
    email: MutableState<String> ,
    password: MutableState<String> ,
    onNavigate: () -> Unit ,
    context: Context ,
) {
    Button(
        onClick = {
            if (email.value == "prathi" && password.value == "12345") {
                afterLogin(email.value,password.value)
                email.value = ""
                password.value = ""
                onNavigate()
            } else {
                Toast.makeText(
                    context,
                    "Email and password incorrect",
                    Toast.LENGTH_LONG,
                ).show()
                afterLogin(email.value,password.value)
            }
        },
        modifier =
            Modifier
                .fillMaxWidth().fillMaxHeight(0.3f)
                .padding(horizontal = 5.dp),
        shape = RoundedCornerShape(15.dp),
    ) {
        Text(
            text = "LOGIN",
            color = if (isSystemInDarkTheme()) Color.Black else Color.White,
            fontWeight = FontWeight.ExtraBold,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LoginEmailInput(email: MutableState<String>) {
    Text(text = "Email:", fontWeight = FontWeight.ExtraBold, color = if (isSystemInDarkTheme()) Color.White else Color.Black)
    OutlinedTextField(
        value = email.value,
        onValueChange = { email.value = it },
        label = { Text(text = "") },
        modifier = Modifier.fillMaxWidth(),
        leadingIcon = {
            Icon(painter = painterResource(id = R.drawable.baseline_email_24), contentDescription = "")
        },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LoginPasswordInput(
    password: MutableState<String>,
    visible: MutableState<Boolean>,
) {
    Text(text = "Password:", fontWeight = FontWeight.ExtraBold, color = if (isSystemInDarkTheme()) Color.White else Color.Black)
    OutlinedTextField(
        value = password.value,
        onValueChange = { password.value = it },
        label = { Text(text = "") },
        modifier = Modifier.fillMaxWidth(),
        visualTransformation = if (visible.value) VisualTransformation.None else PasswordVisualTransformation(),
        trailingIcon = {
            IconButton(onClick = { visible.value = !visible.value }) {
                Icon(
                    painter =
                        painterResource(
                            id = if (visible.value) R.drawable.baseline_visibility_24 else R.drawable.baseline_visibility_off_24,
                        ),
                    contentDescription = "",
                )
            }
        },
        leadingIcon = {
            Icon(painter = painterResource(id = R.drawable.baseline_password_24), contentDescription = "")
        },
    )
}
