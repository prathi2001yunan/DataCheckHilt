package tech.crypton.daggerhilt.viewmodel

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel

@HiltViewModel
class DashBoardViewModel : ViewModel (){

}