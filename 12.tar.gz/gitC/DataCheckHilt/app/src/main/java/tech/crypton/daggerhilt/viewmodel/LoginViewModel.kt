package tech.crypton.daggerhilt.viewmodel


import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class LoginViewModel @Inject constructor(): ViewModel(){
    private val dataStore = mutableStateOf(Session())
    val dataStoreState: State<Session> = dataStore
    val email = mutableStateOf("")
    val password = mutableStateOf("")
    val visible = mutableStateOf(false)
    val isAuthenticated = mutableStateOf<Boolean>(false)
    
    fun afterLogin(email: String, password: String) {
        dataStore.value = Session(email, password)
    }
    
    
    
}
