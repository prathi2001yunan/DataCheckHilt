package tech.crypton.daggerhilt.viewmodel

data class Session(val userEmail: String = "", val userPassword: String = "")
